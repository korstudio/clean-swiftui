//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import SwiftUI

struct ___VARIABLE_sceneName__ViewState: ObservableObject, Equatable {
//    @Published var userData: UserData()
//    @Published var router: ViewRouter()
//    @Published var system: ViewSystem()
}

#if DEBUG
struct ___VARIABLE_sceneName__View_Previews: PreviewProvider {
    @State static var isDisplayed = true

    static var previews: some View {
//        ___VARIABLE_sceneName__(xx)
//            .inject(.preview)
//            .previewDevice("iPhone 12 Pro")
//            .previewDisplayName("iPhone 12 Pro")
    }
}
#endif
