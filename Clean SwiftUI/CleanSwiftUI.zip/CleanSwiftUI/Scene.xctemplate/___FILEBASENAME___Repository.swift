//
//  ___FILENAME___
//  ___PROJECTNAME___
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright © ___YEAR___ ___ORGANIZATIONNAME___. All rights reserved.
//

import SwiftUI

protocol ___VARIABLE_sceneName__Repository: BaseRepository {
    
}

// MARK: - Implementation

struct ___VARIABLE_sceneName__RepositoryImpl: ___VARIABLE_sceneName__Repository {
    // implement base repository
}

// MARK: - API handling

extension ___VARIABLE_sceneName__RepositoryImpl {
    
}
